#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h>

typedef struct {
    int data;
    int prop_time;
} packet;

typedef struct {
    int ack_no;
    int rtt;
} ack;

int main() {
    int server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Error creating the socket");
        return 1;
    }

    struct sockaddr_in server_address, client_address;
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(8080);
    server_address.sin_addr.s_addr = INADDR_ANY;

    if (bind(server_socket, (struct sockaddr *)&server_address, sizeof(server_address)) < 0) {
        perror("Error binding");
        return 1;
    }

    listen(server_socket, 5);
    printf("Server listening on port 8080...\n");

    socklen_t client_len = sizeof(client_address);
    int client_socket = accept(server_socket, (struct sockaddr *)&client_address, &client_len);

    int tt, tp, no_of_packets;
    recv(client_socket, &tt, sizeof(tt), 0);
    recv(client_socket, &tp, sizeof(tp), 0);
    recv(client_socket, &no_of_packets, sizeof(no_of_packets), 0);

    printf("Parameters Received -> Tt: %d, Tp: %d, Packets: %d\n", tt, tp, no_of_packets);

    // Noiseless hai, matlab packet loss ka check nahi chahiye
    // Seeds receive karo aur ACK bhej do
    for (int i = 1; i <= no_of_packets; i++) {
        packet p;
        recv(client_socket, &p, sizeof(p), 0);

        printf("--------------------------------------------------------------------\n");
        printf("Packet %d received at t = %d, sending ACK\n", p.data, p.prop_time);

        ack a;
        a.ack_no = p.data;
        // ACK client tak pahunchne ka time = server par receive hone ka time + Tp
        a.rtt = p.prop_time + tp; 
        
        send(client_socket, &a, sizeof(a), 0);
    }

    close(client_socket);
    close(server_socket);
    return 0;
}