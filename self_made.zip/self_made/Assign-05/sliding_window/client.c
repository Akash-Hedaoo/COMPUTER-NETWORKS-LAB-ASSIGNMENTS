#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h>

typedef struct {
    int data;
    int prop_time;
} packet;

typedef struct {
    int ack_no;
    int rtt;
} ack;

int main() {
    int client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket < 0) {
        perror("Error creating the socket ");
        return 1;
    }

    struct sockaddr_in client_address;
    client_address.sin_family = AF_INET;
    client_address.sin_port = htons(8080);
    client_address.sin_addr.s_addr = inet_addr("127.0.0.1");
    
    if (connect(client_socket, (struct sockaddr *)&client_address, sizeof(client_address)) < 0) {
        perror("Error connecting the socket ");
        return 1;
    }

    int tt, tp, no_of_packets;
    printf("Enter Tt : ");
    scanf("%d", &tt);
    printf("Enter Tp : ");
    scanf("%d", &tp);
    printf("Enter no of packets : ");
    scanf("%d", &no_of_packets);

    // Send initial data to server
    send(client_socket, &tt, sizeof(tt), 0);
    send(client_socket, &tp, sizeof(tp), 0);
    send(client_socket, &no_of_packets, sizeof(no_of_packets), 0);

    // Calculate Window Size: W = 1 + 2a (where a = Tp/Tt)
    // Basic math expansion: W = 1 + (2 * Tp) / Tt
    int w = 1 + (2 * tp) / tt;
    
    printf("Transmission time = %d \n", tt);
    printf("Propagation time = %d \n", tp);
    printf("Calculated Window Size W = %d \n", w);

    int next_to_send = 1;
    int next_to_ack = 1;

    // Simulate Sliding Window logically
    while (next_to_ack <= no_of_packets) {
        
        // 1. Packet tab tak bhejo jab tak window bhar nahi jati
        while (next_to_send <= no_of_packets && (next_to_send - next_to_ack) < w) {
            int send_time = next_to_send * tt; // Continuous pipeline sending
            packet p = {next_to_send, send_time + tp};
            
            printf("--------------------------------------------------------------------\n");
            printf("Packet %d sent at t = %d\n", next_to_send, send_time);
            send(client_socket, &p, sizeof(p), 0);
            
            next_to_send++;
        }
        
        // 2. Window full ho gayi, ab ACK receive karo taaki window slide ho
        ack a;
        recv(client_socket, &a, sizeof(a), 0);
        printf("Packet %d ack recieved at t = %d\n", a.ack_no, a.rtt);
        
        next_to_ack++;
    }

    printf("--------------------------------------------------------------------\n");
    printf("Transmission Completed \n");
    
    // Formula for noiseless pipelining time: Total time = (Total Packets * Tt) + 2*Tp
    int total_time = (no_of_packets * tt) + (2 * tp);
    printf("Total simulated time = %d \n", total_time);

    close(client_socket);
    return 0;
}