#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h>

typedef struct {
    int data;
} packet;

typedef struct {
    int ack_no;
} ack;

int main() {
    int client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket < 0) {
        perror("Error creating the socket ");
        return 1;
    }

    struct sockaddr_in client_address;
    client_address.sin_family = AF_INET;
    client_address.sin_port = htons(8080);
    client_address.sin_addr.s_addr = inet_addr("127.0.0.1");
    
    if (connect(client_socket, (struct sockaddr *)&client_address, sizeof(client_address)) < 0) {
        perror("Error connecting the socket ");
        return 1;
    }

    int window_size, no_of_packets, nth_lost;
    printf("Enter Window Size : ");
    scanf("%d", &window_size);
    printf("Enter no of packets : ");
    scanf("%d", &no_of_packets);
    printf("Enter 'n' for every nth packet to be lost : ");
    scanf("%d", &nth_lost);

    send(client_socket, &window_size, sizeof(window_size), 0);
    send(client_socket, &no_of_packets, sizeof(no_of_packets), 0);
    send(client_socket, &nth_lost, sizeof(nth_lost), 0);

    int base = 1;
    int sent_flag[100] = {0};  // Track if a packet has been sent at least once
    int acked[100] = {0};      // Track explicitly ACKed packets
    int retransmit[100] = {0}; // Track which packets need retransmission

    while (base <= no_of_packets) {
        printf("\n--------------------------------------------------------------------\n");
        printf("Current Client Window: [ ");
        for (int i = base; i < base + window_size && i <= no_of_packets; i++) {
            if (acked[i]) printf("(%d) ", i); // Bracket means already ACKed and buffered at server
            else printf("%d ", i);
        }
        printf("]\n");

        int sent_in_this_round = 0;

        // Bhejo sirf naye packets YA jinhe retransmit karna hai
        for (int i = base; i < base + window_size && i <= no_of_packets; i++) {
            if (!sent_flag[i]) {
                printf("Sending new Packet %d\n", i);
                packet p = {i};
                send(client_socket, &p, sizeof(p), 0);
                sent_flag[i] = 1;
                sent_in_this_round++;
            } else if (retransmit[i]) {
                printf("Retransmitting Lost Packet %d\n", i);
                packet p = {i};
                send(client_socket, &p, sizeof(p), 0);
                retransmit[i] = 0; // Clear flag after retransmitting
                sent_in_this_round++;
            }
        }

        // ACKs receive karo (sirf utne jitne is round mein bheje gaye)
        for (int i = 0; i < sent_in_this_round; i++) {
            ack a;
            recv(client_socket, &a, sizeof(a), 0);

            if (a.ack_no < 0) {
                // Server ne -1 (Negative value) bheji to simulate timeout/loss
                int lost_pkt = -a.ack_no; 
                printf("!! Timeout !! Packet %d lost.\n", lost_pkt);
                retransmit[lost_pkt] = 1; // Mark for retransmission in next round
            } else {
                printf("ACK received for packet %d.\n", a.ack_no);
                acked[a.ack_no] = 1;
            }
        }

        // Window slide karo
        int old_base = base;
        while (acked[base] == 1 && base <= no_of_packets) {
            base++;
        }
        if (base > old_base) {
            printf("=> Window slides forward. Base is now %d\n", base);
        } else {
            printf("=> Window STUCK at base %d. Waiting for packet %d to be retransmitted.\n", base, base);
        }
    }

    printf("\n--------------------------------------------------------------------\n");
    printf("All packets sent successfully using Selective Repeat Protocol.\n");

    close(client_socket);
    return 0;
}