#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h>

typedef struct {
    int data;
} packet;

typedef struct {
    int ack_no;
} ack;

int main() {
    int server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Error creating the socket");
        return 1;
    }

    struct sockaddr_in server_address, client_address;
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(8080);
    server_address.sin_addr.s_addr = INADDR_ANY;

    if (bind(server_socket, (struct sockaddr *)&server_address, sizeof(server_address)) < 0) {
        perror("Error binding");
        return 1;
    }

    listen(server_socket, 5);
    printf("Server listening on port 8080...\n");

    socklen_t client_len = sizeof(client_address);
    int client_socket = accept(server_socket, (struct sockaddr *)&client_address, &client_len);

    int window_size, no_of_packets, nth_lost;
    recv(client_socket, &window_size, sizeof(window_size), 0);
    recv(client_socket, &no_of_packets, sizeof(no_of_packets), 0);
    recv(client_socket, &nth_lost, sizeof(nth_lost), 0);

    int expected_packet = 1;
    int received_counts[100] = {0}; 
    int buffered[100] = {0}; // Receiver buffer for out-of-order packets

    while (expected_packet <= no_of_packets) {
        packet p;
        int recv_status = recv(client_socket, &p, sizeof(p), 0);
        if (recv_status <= 0) break;

        received_counts[p.data]++;

        // Simulate Loss
        if (nth_lost != 0 && (p.data % nth_lost == 0) && received_counts[p.data] == 1) {
            printf("\n=> Packet %d dropped intentionally.\n", p.data);
            
            // Send NAK (negative value of packet to identify which one lost)
            ack a = {-p.data}; 
            send(client_socket, &a, sizeof(a), 0);
            continue;
        } 

        printf("\n=> Packet %d received at server.\n", p.data);
        
        if (p.data == expected_packet) {
            // Correct expected packet arrived
            buffered[p.data] = 1;
            printf("   In-order packet. Delivering %d to application.\n", p.data);
            
            // Check agar aage ke koi packets pehle se buffered hain
            while (buffered[expected_packet] == 1 && expected_packet <= no_of_packets) {
                if (expected_packet != p.data) {
                    printf("   Also delivering buffered packet %d to application.\n", expected_packet);
                }
                expected_packet++;
            }
            printf("   Receiver Window expects packet %d next.\n", expected_packet);
            
            // Send normal ACK
            ack a = {p.data};
            send(client_socket, &a, sizeof(a), 0);
        } 
        else if (p.data > expected_packet) {
            // Out of order packet but within window
            if (!buffered[p.data]) {
                buffered[p.data] = 1;
                printf("   Out-of-order packet. BUFFERING packet %d.\n", p.data);
            } else {
                printf("   Packet %d already buffered.\n", p.data);
            }
            // Selective Repeat mein out of order ki bhi ACK bheji jati hai
            ack a = {p.data};
            send(client_socket, &a, sizeof(a), 0);
        }
    }

    close(client_socket);
    close(server_socket);
    return 0;
}