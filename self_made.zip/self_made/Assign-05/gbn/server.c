#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h>

typedef struct {
    int data;
} packet;

typedef struct {
    int ack_no;
} ack;

int main() {
    int server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Error creating the socket");
        return 1;
    }

    struct sockaddr_in server_address, client_address;
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(8080);
    server_address.sin_addr.s_addr = INADDR_ANY;

    if (bind(server_socket, (struct sockaddr *)&server_address, sizeof(server_address)) < 0) {
        perror("Error binding");
        return 1;
    }

    listen(server_socket, 5);
    printf("Server listening on port 8080...\n");

    socklen_t client_len = sizeof(client_address);
    int client_socket = accept(server_socket, (struct sockaddr *)&client_address, &client_len);

    int window_size, no_of_packets, nth_lost;
    recv(client_socket, &window_size, sizeof(window_size), 0);
    recv(client_socket, &no_of_packets, sizeof(no_of_packets), 0);
    recv(client_socket, &nth_lost, sizeof(nth_lost), 0);

    printf("Simulation Parameters -> Window Size: %d, Total Packets: %d, Loss every %dth packet\n", window_size, no_of_packets, nth_lost);

    int expected_packet = 1;
    int received_counts[1000] = {0}; // Track record for dropping logic

    while (expected_packet <= no_of_packets) {
        packet p;
        int recv_status = recv(client_socket, &p, sizeof(p), 0);
        if (recv_status <= 0) break;

        received_counts[p.data]++;

        // Drop logic: Agar 'n' non-zero hai, packet 'n' ka multiple hai, aur pehli baar aa raha hai
        if (nth_lost != 0 && (p.data % nth_lost == 0) && received_counts[p.data] == 1) {
            printf("Packet %d dropped intentionally.\n", p.data);
            
            // Dummy NAK bhej do (client ko unblock karne ke liye)
            ack a = {-1};
            send(client_socket, &a, sizeof(a), 0);
        } 
        else if (p.data == expected_packet) {
            // Correct in-order packet
            printf("Packet %d received successfully. Sending ACK.\n", p.data);
            ack a = {p.data};
            send(client_socket, &a, sizeof(a), 0);
            expected_packet++;
        } 
        else {
            // Out of order packet (GBN ignores these)
            printf("Packet %d received out of order (Expected %d). Dropping & Sending NAK.\n", p.data, expected_packet);
            ack a = {-1};
            send(client_socket, &a, sizeof(a), 0);
        }
    }

    close(client_socket);
    close(server_socket);
    return 0;
}