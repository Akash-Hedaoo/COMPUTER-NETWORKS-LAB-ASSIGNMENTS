#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h>

typedef struct {
    int data;
} packet;

typedef struct {
    int ack_no;
} ack;

int main() {
    int client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket < 0) {
        perror("Error creating the socket ");
        return 1;
    }

    struct sockaddr_in client_address;
    client_address.sin_family = AF_INET;
    client_address.sin_port = htons(8080);
    client_address.sin_addr.s_addr = inet_addr("127.0.0.1");
    
    if (connect(client_socket, (struct sockaddr *)&client_address, sizeof(client_address)) < 0) {
        perror("Error connecting the socket ");
        return 1;
    }

    int window_size, no_of_packets, nth_lost;
    printf("Enter Window Size : ");
    scanf("%d", &window_size);
    printf("Enter no of packets : ");
    scanf("%d", &no_of_packets);
    printf("Enter 'n' for every nth packet to be lost (e.g., 3 means every 3rd packet, 0 for none) : ");
    scanf("%d", &nth_lost);

    // Sending parameters to server
    send(client_socket, &window_size, sizeof(window_size), 0);
    send(client_socket, &no_of_packets, sizeof(no_of_packets), 0);
    send(client_socket, &nth_lost, sizeof(nth_lost), 0);

    int base = 1;
    int next_to_send = 1;

    while (base <= no_of_packets) {
        printf("\n--------------------------------------------------------------------\n");
        printf("Current Window: [ ");
        for (int i = base; i < base + window_size && i <= no_of_packets; i++) {
            printf("%d ", i);
        }
        printf("]\n");

        int sent_in_this_round = 0;

        // Bhejo jab tak window full na ho jaye
        while (next_to_send < base + window_size && next_to_send <= no_of_packets) {
            printf("Sending Packet %d\n", next_to_send);
            packet p = {next_to_send};
            send(client_socket, &p, sizeof(p), 0);
            next_to_send++;
            sent_in_this_round++;
        }

        int timeout = 0;
        int check_pkt = base; // NAYA LOGIC: Track karne ke liye ki hum kis packet ki report dekh rahe hain

        // Jo batch bheja hai, uski ACKs receive karo
        for (int i = 0; i < sent_in_this_round; i++) {
            ack a;
            recv(client_socket, &a, sizeof(a), 0);

            if (a.ack_no == -1) {
                if (!timeout) { 
                    // Sirf pehle dropped packet par lost/timeout message dikhao
                    printf("!! Timeout !! Packet %d lost. Window stuck at %d.\n", check_pkt, base);
                    timeout = 1;
                } else {
                    // Agar ek baar loss detect ho gaya, baaki sab packets rejected mane jayenge
                    printf("Packet %d rejected (Out of order).\n", check_pkt);
                }
            } else {
                if (!timeout) { 
                    base = a.ack_no + 1;
                    printf("ACK received for packet %d. Window shifts -> Base is now %d\n", a.ack_no, base);
                } else {
                    // Waise GBN mein yeh case server side handle hota hai (out of order discard), par safety ke liye
                    printf("Packet %d rejected (Out of order).\n", check_pkt);
                }
            }
            check_pkt++; // Har ACK/NAK ke baad agle packet par check move karo
        }

        // Agar loss hua, toh Go-Back-N lagao
        if (timeout) {
            printf("Go-Back-N triggered! Retransmitting all packets from %d...\n", base);
            next_to_send = base; 
        }
    }

    printf("\n--------------------------------------------------------------------\n");
    printf("All packets sent successfully using Go-Back-N Protocol.\n");

    close(client_socket);
    return 0;
}